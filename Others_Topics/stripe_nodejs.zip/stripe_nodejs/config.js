// config.js
module.exports = {
    stripeSecretKey: 'sk_test_51NYxHCSCd69U1CZjSuV0F9eMIVA2F3CtGhi878x7oswGizIDxlB5UFUzBOqCqgIH7duu1PSOnVJQYyatBKBLoVhd00N9kaZyFT',
};
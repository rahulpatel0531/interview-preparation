// app.js
const express = require('express');
const bodyParser = require('body-parser');
const stripe = require('stripe')(require('./config').stripeSecretKey);

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Define a route to handle the payment
app.post('/payment', async (req, res) => {
    try {
        // Use the Stripe API to create a payment intent
        const paymentIntent = await stripe.paymentIntents.create({
            amount: 1000, // Amount in cents (e.g., $10.00)
            currency: 'usd',
            description: 'Example payment',
            payment_method_types: ['card'],
        });
        console.log('paymentIntent ', paymentIntent);


        // Handle the payment on the server-side and return the result to the client
        const paymentResult = await stripe.paymentIntents.confirm(paymentIntent.id);

        if (paymentResult.status === 'succeeded') {
            res.status(200).json({ message: 'Payment successful!' });
        } else {
            res.status(500).json({ message: 'Payment failed.' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
